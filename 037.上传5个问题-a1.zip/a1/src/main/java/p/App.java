package p;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

@Controller
public class App {
    User user=new User();

    /***
     * 首页
     * @return
     */
    @RequestMapping("/")
    public String toWelcome() {
        return "welcome";
    }

    /***
     * Thymeleaf返回值
     * @param request
     * @param model
     * @return
     */
    @RequestMapping("/doForm")
    public String toScore(HttpServletRequest request, Model model) throws IOException, InterruptedException {
        user.username=request.getParameter("username");
        user.code[0]="";
        user.code[1]=request.getParameter("code1");
        user.code[2]=request.getParameter("code2");
        user.code[3]=request.getParameter("code3");
        user.code[4]=request.getParameter("code4");
        user.code[5]=request.getParameter("code5");
        user.score[0]=0;
        user.score[1]=0;
        user.score[2]=0;
        user.score[3]=0;
        user.score[4]=0;
        user.score[5]=0;
        //保存文件
        try {
            SaveFile saveFile1=new SaveFile("1-"+user.username+".c",user.code[1]);
            SaveFile saveFile2=new SaveFile("2-"+user.username+".c",user.code[2]);
            SaveFile saveFile3=new SaveFile("3-"+user.username+".c",user.code[3]);
            SaveFile saveFile4=new SaveFile("4-"+user.username+".c",user.code[4]);
            SaveFile saveFile5=new SaveFile("5-"+user.username+".c",user.code[5]);
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("保存出错。。。");
        }
        //运行test.sh shell脚本
        String fileNameNoSuffix1="1-"+user.username;
        String fileNameNoSuffix2="2-"+user.username;
        String fileNameNoSuffix3="3-"+user.username;
        String fileNameNoSuffix4="4-"+user.username;
        String fileNameNoSuffix5="5-"+user.username;
        String []strArr1={"sh","/home/u18/webtest/test.sh",fileNameNoSuffix1,".c"};
        GoShell goShell1=new GoShell(strArr1);

        String []strArr2={"sh","/home/u18/webtest/test.sh",fileNameNoSuffix2,".c"};
        GoShell goShell2=new GoShell(strArr2);
        String []strArr3={"sh","/home/u18/webtest/test.sh",fileNameNoSuffix3,".c"};
        GoShell goShell3=new GoShell(strArr3);
        String []strArr4={"sh","/home/u18/webtest/test.sh",fileNameNoSuffix4,".c"};
        GoShell goShell4=new GoShell(strArr4);
        String []strArr5={"sh","/home/u18/webtest/test.sh",fileNameNoSuffix5,".c"};
        GoShell goShell5=new GoShell(strArr5);

//        html-thymeleaf网页显示
        model.addAttribute("msg_u",user.username);
        model.addAttribute("msg_c_1",user.code[1]);
        model.addAttribute("msg_c_2",user.code[2]);
        model.addAttribute("msg_c_3",user.code[3]);
        model.addAttribute("msg_c_4",user.code[4]);
        model.addAttribute("msg_c_5",user.code[5]);
        model.addAttribute("msg_s_1",user.score[1]);
        model.addAttribute("msg_s_2",user.score[2]);
        model.addAttribute("msg_s_3",user.score[3]);
        model.addAttribute("msg_s_4",user.score[4]);
        model.addAttribute("msg_s_5",user.score[5]);
        //返回score.html
        return "score";
    }
}