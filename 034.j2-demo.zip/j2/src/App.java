import java.io.IOException;

public class App {
    public static void main(String[] args) throws IOException, InterruptedException {
        String[] strArr={"sh","/home/u18/webtest/test.sh","user01","3333333"};
        GoShell goShell=new GoShell(strArr);
    }
}