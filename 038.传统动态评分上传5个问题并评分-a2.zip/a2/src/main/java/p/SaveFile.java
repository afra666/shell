package p;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class SaveFile {
    public SaveFile(String fileNameWithC,String ctx) throws IOException {

        //windows
        //File file=new File("D:/webtest/"+todayDirName+"/"+username+"-code01"+".c");
        //File dir=new File("D:/webtest/"+todayDirName);

        //ubuntu
        //---------------------------/home/ad/webtest/root1-code.c
        File file=new File("/home/u18/webtest/"+fileNameWithC);
        File dir=new File("/home/u18/webtest/");

        if (!dir.exists()){
            dir.mkdirs();
            System.out.println(dir+"目录创建成功");
        }
        if (!file.exists()){
            file.createNewFile();
            //将context写入file
            BufferedWriter out = new BufferedWriter(new FileWriter(file));
            out.write(ctx); // \r\n即为换行

            out.flush(); // 把缓存区内容压入文件
            out.close(); // 最后记得关闭文件
            System.out.println(file+"代码提交成功");
        }
    }
}
