package p;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {
    String qnum;
    String username;
    String []code=new String[6];
    int []score=new int[6];
}
