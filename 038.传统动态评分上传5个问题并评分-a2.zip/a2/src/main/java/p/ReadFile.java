package p;

import lombok.Data;

import java.io.*;

/***
 * ReadFile readFile=new ReadFile("/home/u18/webtest/score/1-username-r.txt");
 *
 */
@Data
public class ReadFile {
    String valueStr;
    ReadFile(String file) throws IOException {


//        String filePath = "./r.txt";
        String filePath =file;
        FileInputStream fin = new FileInputStream(filePath);
        InputStreamReader reader = new InputStreamReader(fin);
        BufferedReader buffReader = new BufferedReader(reader);
        String strTmp = "";
        while ((strTmp = buffReader.readLine()) != null) {
            valueStr=strTmp;
//            System.out.println(valueStr);
        }
        buffReader.close();
    }
}
