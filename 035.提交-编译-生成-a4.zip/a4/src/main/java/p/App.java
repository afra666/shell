package p;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

@Controller
public class App {
    User user=new User();

    /***
     * 首页
     * @return
     */
    @RequestMapping("/")
    public String toWelcome() {
        return "welcome";
    }

    /***
     * Thymeleaf返回值
     * @param request
     * @param model
     * @return
     */
    @RequestMapping("/doForm")
    public String toScore(HttpServletRequest request, Model model) throws IOException, InterruptedException {
        user.username=request.getParameter("username");
        user.code=request.getParameter("code");
        user.qnum=request.getParameter("select");
        user.score=0;
        //保存文件
        try {
            SaveFile saveFile=new SaveFile(user);
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("保存出错。。。");
        }
        //运行shell脚本
       String []strArr={"sh","/home/u18/webtest/test.sh",user.getQnum()+"-"+user.getUsername(),"-1"};
        GoShell goShell=new GoShell(strArr);
        //html-thymeleaf网页显示
        model.addAttribute("msg1",user.username);
        model.addAttribute("msg2",user.code);
        model.addAttribute("msg3",user.score);
        //返回score.html
        return "score";
    }
}